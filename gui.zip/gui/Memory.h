#ifndef MEMORY_H
#define MEMORY_H

#include <string>

using namespace std;

class Memory {
    string memory[256];

public:
    Memory();

    const int memory_size = 256;

    string getCell(int address);

    void setCell(int address, string val);
};

#endif
