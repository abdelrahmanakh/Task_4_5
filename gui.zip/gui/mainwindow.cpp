#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QRegularExpression>
#include <QRegularExpressionValidator>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QSpacerItem>
#include <regex>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    QWidget *centralWidget = new QWidget(this);
    QHBoxLayout *mainLayout = new QHBoxLayout(centralWidget);//main layout
    QVBoxLayout *leftLayout = new QVBoxLayout;//left column layout
    QVBoxLayout *rightLayout = new QVBoxLayout;//left column layout

    //code Enter box
    ui->codeInputTextEdit = new QLineEdit;
    ui->codeInputTextEdit->setPlaceholderText("Enter code here...");
    ui->codeInputTextEdit->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Minimum);
    leftLayout->addWidget(ui->codeInputTextEdit);
    QRegularExpression regex("^[0-9A-F]{4}$");
    QRegularExpressionValidator *validator = new QRegularExpressionValidator(regex, this);
    ui->codeInputTextEdit->setValidator(validator);
    ui->codeInputTextEdit->setToolTip("Each instruction must be exactly 4 characters.");

    //register table
    ui->registerTableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->registerTableWidget->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->registerTableWidget->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    ui->registerTableWidget->setHorizontalHeaderLabels({"Registers"});
    leftLayout->addWidget(ui->registerTableWidget, 1);

    //adding leftside layout to the main
    mainLayout->addLayout(leftLayout,1);

    ui->MemoryLabel->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Minimum);
    rightLayout->addWidget(ui->MemoryLabel);

    //adding memory to the right side of the layout
    ui->memoryTableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->memoryTableWidget->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->memoryTableWidget->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    rightLayout->addWidget(ui->memoryTableWidget);
    mainLayout->addLayout(rightLayout,2);



    //layout for the bottom side
    QVBoxLayout *bottomLayout = new QVBoxLayout;

    //Error Display
    ui->ErrorDisplay = new QLabel("No errors");  // Assuming you have an errorLabel in your UI
    ui->ErrorDisplay->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Minimum);
    bottomLayout->addWidget(ui->ErrorDisplay);

    //Buttons Raw
    QHBoxLayout *buttonLayout = new QHBoxLayout;

    //start address in memory
    buttonLayout->addWidget(ui->startAddressLineEdit,2);
    ui->startAddressLineEdit->setPlaceholderText("Enter start address here...");
    QRegularExpression re("^[0-9A-F]{2}$");
    QRegularExpressionValidator *validatorcounter = new QRegularExpressionValidator(re, this);
    ui->startAddressLineEdit->setValidator(validatorcounter);
    ui->startAddressLineEdit->setToolTip("Memory Address must be 2 characters.");

    //buttons
    buttonLayout->addWidget(ui->runButton,1);
    buttonLayout->addWidget(ui->clearMemoryButton,1);
    buttonLayout->addWidget(ui->clearRegisterButton,1);
    bottomLayout->addLayout(buttonLayout);//add buttons raw to bottom layout

    leftLayout->addLayout(bottomLayout);    //adding bottom layout to the main
    this->setCentralWidget(centralWidget);
    centralWidget->setLayout(mainLayout);

    memory = new Memory();
    currentAddress = 0;

    //Setting up the tables and display default vlaues
    updateMemoryTable();
    updateRegisterTable();


    // Set up vertical and Horizontal header labels for the memory table
    QStringList memoryLabels;
    for (int i = 0; i < 16; ++i) {
        memoryLabels << QString::number(i, 16).toUpper(); // Convert to hex and make uppercase
    }
    ui->memoryTableWidget->setVerticalHeaderLabels(memoryLabels);
    ui->memoryTableWidget->setHorizontalHeaderLabels(memoryLabels);

    // Set up vertical header labels for the register table
    QStringList registerLabels;
    for (int i = 0; i < 16; ++i) {
        registerLabels << QString::number(i, 16).toUpper(); // Convert to hex and make uppercase
    }
    ui->registerTableWidget->setVerticalHeaderLabels(registerLabels);

    //connecting the gui to the actions
    connect(ui->codeInputTextEdit, &QLineEdit::returnPressed, this, &MainWindow::onInstructionEntered);
    connect(ui->runButton, &QPushButton::clicked, this, &MainWindow::onRunButtonClicked);
    connect(ui->clearMemoryButton, &QPushButton::clicked, this, &MainWindow::clearMemory);
    connect(ui->clearRegisterButton, &QPushButton::clicked, this, &MainWindow::clearRegisters);
    connect(ui->startAddressLineEdit, &QLineEdit::returnPressed, this, &MainWindow::setStartAddress);

    // Styling the GUI
    setStyleSheet("background-color: #2e2e2e; color: #ffffff;");

    // Memory table styling
    ui->memoryTableWidget->setStyleSheet(
        "QTableWidget { background-color: #3c3c3c; color: #ffffff; border: 1px solid #555555; }"
        "QTableWidget::item { border: 1px solid #555555; padding: 5px; display: flex; }"
        );
    ui->memoryTableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);

    // Register table styling
    ui->registerTableWidget->setStyleSheet(
        "QTableWidget { background-color: #3c3c3c; color: #ffffff; border: 1px solid #555555; }"
        "QTableWidget::item { border: 1px solid #555555; padding: 5px; }"
        );
    ui->registerTableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);

    // Common button styling
    QString buttonStyle =
        "QPushButton { background-color: #3c3c3c; color: white; border: none; padding: 10px 20px; "
        "text-align: center; text-decoration: none; display: inline-block; font-size: 16px; "
        "margin: 4px 2px; cursor: pointer; border-radius: 5px; }"
        "QPushButton:hover { background-color: red; }";

    // Apply style to all buttons
    ui->runButton->setStyleSheet(
        "QPushButton { background-color: #3c3c3c; color: white; border: none; padding: 10px 20px; "
        "text-align: center; text-decoration: none; display: inline-block; font-size: 16px; "
        "margin: 4px 2px; cursor: pointer; border-radius: 5px; }"
        "QPushButton:hover { background-color: #45a049; }"
        );

    ui->clearMemoryButton->setStyleSheet(buttonStyle);
    ui->clearRegisterButton->setStyleSheet(buttonStyle);

    // Set icon for the Run button
    QIcon runIcon("D:/Programming/OOP/Task 5 GUI/gui/play.png"); // Update this path to your icon file
    ui->runButton->setIcon(runIcon);
    ui->runButton->setIconSize(QSize(24, 24)); // Adjust icon size as needed
    ui->runButton->setText(""); // Remove the text from the button


    // Increase the size of the startAddressInput area
    ui->startAddressLineEdit->setMinimumSize(QSize(150, 30)); // Adjust the size as needed
    ui->startAddressLineEdit->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);

    // Error display styling
    ui->ErrorDisplay->setStyleSheet(
        "QLabel { color: #ff4c4c; background-color: #2e2e2e; padding: 5px; border: 1px solid #ff4c4c; "
        "border-radius: 3px; }"
        );

    // Overall widget styling
    setStyleSheet("QWidget { font-size: 12pt; font-family: Arial; }");






}
void MainWindow::onInstructionEntered() {
    QString code = ui->codeInputTextEdit->text(); // Get the text from the QLineEdit

    ui->ErrorDisplay->clear();

    // Check if the input is valid
    if (code.length() == 4) {
        std::string instruction1 = code.mid(0, 2).toStdString();
        std::string instruction2 = code.mid(2, 2).toStdString();

        //check if we are in the boundaries
        if(currentAddress >= 0 && currentAddress < memory->memory_size -1) {
            memory->setCell(currentAddress, instruction1);
            memory->setCell(currentAddress + 1, instruction2);
            currentAddress += 2;
            updateMemoryTable();
        } else  {
            // Display the error message in the QLabel if out of boundaries
            ui->ErrorDisplay->setText("Error: Address is out of bounds. Please enter a valid address.");
        }
    } else {
        ui->ErrorDisplay->setText("Please enter exactly 4 hexadecimal characters (0-9, A-F).");
    }

    ui->codeInputTextEdit->clear();
}

//to update the memory in the gui with any upadates to the memory declared above
void MainWindow::updateMemoryTable() {
    for (int row = 0; row < 16; ++row) {
        for (int col = 0; col < 16; ++col) {
            int address = row * 16 + col;
            std::string value = memory->getCell(address);
            ui->memoryTableWidget->setItem(row, col, new QTableWidgetItem(QString::fromStdString(value)));
        }
    }
}

//to update the memory in the gui with any upadates to the memory declared in cpu calss
void MainWindow::updateRegisterTable() {
    for (int row = 0; row < 16; ++row) {
            std::string value = cpu.reg.getCell(row);
            ui->registerTableWidget->setItem(row,0, new QTableWidgetItem(QString::fromStdString(value)));

    }
}


void MainWindow::onRunButtonClicked() {
    ui->ErrorDisplay->clear();

    bool instructionFound = false; // Flag to track if Cxxx is found

    // Iterate through the memory to check for valid "Cxxx" instructions
    for (int i = 0; i < memory->memory_size; i+=2) {
        std::string instruction = memory->getCell(i) + memory->getCell(i+1);

        if (std::regex_match(instruction, std::regex("^C([0-9A-Fa-f]{3})$"))) {
            instructionFound = true;
            break;
        }
    }
    if (instructionFound){
        cpu.resetProgramCounter();
        int memorySize = memory->memory_size;

        // Loop through memory until we find C000 or reach the end of memory
        while (cpu.programCounter < memorySize) { // Ensure programCounter does not exceed memory bounds
            std::string instruction = memory->getCell(cpu.programCounter) + memory->getCell(cpu.programCounter+1);
            if (instruction == "C000") {
                break; // Stop execution if C000 is found
            }
            // Run the next step of the CPU
            cpu.runNextStep(*memory);

            // Increment the program counter
            cpu.incrementProgramCounter();
        }

        // Update the register table and memory table to reflect changes after execution
        updateRegisterTable();
        updateMemoryTable();
    } else {
        ui->ErrorDisplay->setText("Error: No valid 'Cxxx' instruction found in memory.");

    }
}

//clear memory and reset each cell to default value 00
void MainWindow::clearMemory() {
    for (int i = 0; i < memory->memory_size; ++i) {
        memory->setCell(i, "00");
    }
    cpu.programCounter = 0;
    currentAddress = 0;
    updateMemoryTable(); // Refresh the table to show cleared values
}

//clear register and reset each cell to default value 00
void MainWindow::clearRegisters() {
    for (int i = 0; i < 16; ++i) {
        cpu.reg.setCell(i, "00");
    }
    updateRegisterTable(); // Refresh the table to show cleared values
}

//for flexiblity allow user to choose location in memory to edit
void MainWindow::setStartAddress() {
    ui->ErrorDisplay->clear();
    QString hexAddress = ui->startAddressLineEdit->text();
    std::string addressStr = hexAddress.toStdString();      // Convert QString to std::string
    int startAddress = alu.hexToDec(addressStr);
    if (startAddress>=0 && startAddress<256) {
        currentAddress=startAddress;
    } else {
        // Show an error message if the input is invalid
        ui->ErrorDisplay->setText("Invalid start address or out of boundaries. Please enter a hexadecimal value.");
    }
    ui->startAddressLineEdit->clear();
}


MainWindow::~MainWindow()
{
    delete ui;
}
